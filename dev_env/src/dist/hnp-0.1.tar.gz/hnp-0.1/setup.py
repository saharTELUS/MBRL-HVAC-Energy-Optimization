import setuptools

setuptools.setup(name='hnp',
version='0.1',
description='Hyperspace Neighbor Penetration agent',
url='https://github.com/VectorInstitute/MBRL-HVAC-Energy-Optimization/tree/thomas-dev/dev_env/src',
author='Thomas Jiralerspong',
install_requires=[],
author_email='thomasjiralerspong@gmail.com',
packages=setuptools.find_packages(),
zip_safe=False)